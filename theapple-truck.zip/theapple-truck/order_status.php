<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once("config.php");
require 'mailer/vendor/autoload.php';
$mail = new PHPMailer(true);

$curl = curl_init();
$barcodes = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://864f811abb112cb228f4ccc5a7df7d35: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@the-apple-truck.myshopify.com/admin/api/2021-07/orders.json',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);
curl_close($curl);

// print_r($response);
// die();
//echo $response;

$orders = json_decode($response,TRUE);
// print_r(end($orders));
// echo "<br>";
foreach($orders['orders'] as $order)
{
    $select = "select * from shopify_order where order_id = ".$order['id'];
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) > 0)
    {
	    while($row = mysqli_fetch_assoc($result))
	    { 
		    try
            {
                //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->isSMTP();                  
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true; 
                $mail->Username   = 'harpreetkaurhari57@gmail.com';
                $mail->Password   = 'qbsjmgqvutlqbgtg';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
                $mail->Port       = 587;
                $mail->setFrom('harpreetkaurhari57@gmail.com', 'ThePeachTruck');
                $mail->addAddress('kaurh639@gmail.com'); 
                $mail->isHTML(true);
                $mail->Subject = 'Order';
                $mail->Body = '<p>Thank you for your purchase!</p><!DOCTYPE html><html lang="en"> <head> <title>'.$order['email'].'</title> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> <meta name="viewport" content="width=device-width"/> <link rel="stylesheet" type="text/css" href="/assets/notifications/styles.css"/> </head> <body> <table class="body"> <tr> <td> <table class="header row"> <tr> <td class="headercell"> <center> <table class="container"> <tr> <td> <table class="row"> <tr> <td class="shop-namecell"></td><td class="order-numbercell"> <span class="order-numbertext"> Order </span> </td></tr></table> </td></tr></table> </center> </td></tr></table> <table class="row content"> <tr> <td class="contentcell"> <center> <table class="container"> <tr> <td> <h2>'.$order['email'].'</h2> <table class="row actions"> <tr> <td class="empty-line"></td></tr><tr> <td class="actionscell"> <table class="button main-action-cell"> <tr> <td class="buttoncell"><a href="'.$order['order_status_url'].'" class="buttontext">View your order</a></td></tr></table> </td></tr></table> </td></tr></table> </center> </td></tr></table> <table class="row section"> <tr> <td class="sectioncell"> <center> <table class="container"> <tr> <td> <h3>Order summary</h3> </td></tr></table> <table class="container"> <tr> <td> <table class="row"> foreach($order[line_items] as $item){ <tr class="order-listitem"> <td class="order-listitemcell"> <table> <td></td><td class="order-listproduct-description-cell"> '.$item['title'].' <span class="order-listitem-title"> '.$item['name'].' × '.$item['quantity'].'</span><br/> </td><td class="order-listprice-cell"> '.$item['price'].' </td></table> </td></tr>}</table> </td></tr></table> </center> </td></tr></table> <img class="qr-code" src=""/> </td></tr></table> </body></html>';
                $mail->send();
                echo 'Message has been sent';
            }
            catch (Exception $e)
            {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
    }
    else
    {
        $data = $order['id'];//$order['id'].'".$order['created_at']."'.$order['order_number'].'".$order['customer']['first_name']."'.'".$order['customer']['email']."';
        $barcode = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data='.$data;
        $sql = "INSERT INTO shopify_order (order_id,order_number,cust_fname,order_value,order_status,financial_status,barcode) 
        VALUES ('".$order['id']."','".$order['order_number']."','".$order['customer']['first_name']."','".$order['id']."','".$order['order_status_url']."','".$order['financial_status']."','".$barcode."')";
        if (mysqli_query($conn, $sql))
        {
            echo '<div class="alert alert-success">New record has been saved.</div>';
            
            try
            {
                $mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->isSMTP();                  
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true; 
                $mail->Username   = 'harpreetkaurhari57@gmail.com';
                $mail->Password   = 'qbsjmgqvutlqbgtg';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
                $mail->Port       = 587;
                $mail->setFrom('harpreetkaurhari57@gmail.com', 'ThePeachTruck');
                $mail->addAddress('kaurh639@gmail.com'); 
                $mail->isHTML(true);
                $mail->Subject = 'Order';
                $mail->Body = '<p>Thank you for your purchase!</p><!DOCTYPE html><html lang="en"> <head> <title>'.$order['email'].'</title> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> <meta name="viewport" content="width=device-width"/> <link rel="stylesheet" type="text/css" href="/assets/notifications/styles.css"/> </head> <body> <table class="body"> <tr> <td> <table class="header row"> <tr> <td class="headercell"> <center> <table class="container"> <tr> <td> <table class="row"> <tr> <td class="shop-namecell"></td><td class="order-numbercell"> <span class="order-numbertext"> Order </span> </td></tr></table> </td></tr></table> </center> </td></tr></table> <table class="row content"> <tr> <td class="contentcell"> <center> <table class="container"> <tr> <td> <h2>'.$order['email'].'</h2> <table class="row actions"> <tr> <td class="empty-line"></td></tr><tr> <td class="actionscell"> <table class="button main-action-cell"> <tr> <td class="buttoncell"><a href="'.$order['order_status_url'].'" class="buttontext">View your order</a></td></tr></table> </td></tr></table> </td></tr></table> </center> </td></tr></table> <table class="row section"> <tr> <td class="sectioncell"> <center> <table class="container"> <tr> <td> <h3>Order summary</h3> </td></tr></table> <table class="container"> <tr> <td> <table class="row"> foreach($order[line_items] as $item){ <tr class="order-listitem"> <td class="order-listitemcell"> <table> <td></td><td class="order-listproduct-description-cell"> '.$item['title'].' <span class="order-listitem-title"> '.$item['name'].' × '.$item['quantity'].'</span><br/> </td><td class="order-listprice-cell"> '.$item['price'].' </td></table> </td></tr>}</table> </td></tr></table> </center> </td></tr></table> <img class="qr-code" src="'.$barcode.'"/> </td></tr></table> </body></html>';
                $mail->send();
                echo 'Message has been sent';
            }
            catch (Exception $e)
            {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
        else
        {
          '<div class="alert alert-danger">'. $sql . "<br>" . mysqli_error($conn).'</div>';
        }
    }
}
?>

<!-- <div class="center">-->
<!--  <div class="form">-->
<!--    <div class="form-element">-->
<!--      <label for="data-ip">Enter data</label>-->
<!--      <input type="text" id="data-ip">-->
<!--    </div>-->
<!--    <div class="form-element">-->
<!--      <button>Generate QR Code</button>-->
<!--    </div>-->
<!--  </div>-->
<!--  <div class="qr-img">-->
<!--    <img src="">-->
<!--  </div>-->
<!--</div>-->

<script>
// let input = document.querySelector(".form input");
// let button = document.querySelector(".form button");
// let qrImg = document.querySelector(".qr-img img");

// button.addEventListener("click",function(){
//   let data = input.value;
//   if(data.length > 0){
//     let imgSrc = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data="+data;
//     qrImg.src = imgSrc;
//   }
// })
</script>