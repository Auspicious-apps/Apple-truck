
<style>
 .ui-widget-header {
    border: none !important;
    background-color: #fff !important;
}
#dialog h2 {
    font-size: 33px;
}
div#dialog {
    padding: 0px 10px 25px 10px;
}
#dialog p {
    font-size: 18px;
    color: #818181;
    text-align: center;
}  
</style>

<section class="setp_1">
    <div class="row">
      <div class="left_grid">
        <div class="heading">
          <h5>Step 1:</h5>
          <h1>Choose Pickup Location</h1>
        </div>
        <input  id="current_lat" type="hidden" value="" />
        <input  id="current_long" type="hidden" value="" />
        <form>
          <div class="search_form">
          <div class="form-group">
                      
            <input type="text" name="location" id="location" placeholder="SEARCH BY ZIPCODE OR CITY">
            <i class="fa fa-map-marker"></i>
                       <input type="hidden" name="latitude" id="latitude"> 
            <input type="hidden" name="longitude" id="longitude"> 

          </div>
          <div class="form_btn">
                       <input  id="latlng" type="hidden" value="37.839333,-84.270020" />
            <a href="#" id="submit"><img src="https://cdn.shopify.com/s/files/1/0564/3141/1394/files/map-svg.png?v=1626263723"></a>
          </div>
        </div>
        </form>
        <div class="Results">
          <p>0 Results </p>
        </div>
        <div class="list_options">
          <ul class="outer-data">
            
                         <div class="locate_list">
          <h2>Unfortunately, we couldn't locate any Tour Stops near you.</h2>
          <p>Please try these other options</p>
          <ul>
            <li>1) Change your search</li>
            <li>2) Zoom Out</li>
            
          </ul>
        </div>

          </ul>
        </div>

      </div>
          
                    
         <div class="right_grid" id="mapCanvas" style="height: 700px; width:60%;"></div>
         
          
          <div id="postal_code"></div>
      
      <div id="dialog"  class="alert_pop_up" style="display:none;">
        <h2> Wait, When?! </h2>
        <p>Please choose a date for your selected location.</p>
        
        </div>
<!--       
      <div id="dialog" title="Basic dialog">
        <p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
      </div> -->
          

    </div>
  </section>


{% include 'custom-cart-popup'%}

{% include 'error-popup'%}

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD0BEltumBd3qxNjIzVwZ7nAIHEhcKfHug&libraries=places&callback=initAutocomplete" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>


<script>
 $( ".outer-data" ).on("click",".test a", function(event) {
  var check_value = document.querySelector('input[name = "leaflet-base-layers"]:checked');
   
   if(check_value != null){ 

      
    var title = $('.list_click').find('.list_inner h3').text();
    
    var parked_address = $('.list_click').find('.parked_address').text();
    
    var count_miles = $('.list_click').find('.list_inner .count_miles').text();
    
    var radioButtonText = $('input[name=leaflet-base-layers].leaflet-control-layers-selector:checked');
  
    var label_value = radioButtonText.closest('label').find('.pop-up-date').text();
    
    var latitude  = $('.latitude_value').val();

    
    var longitude = $('.longitude_value').val();
   
    var direction_url = "http://maps.google.com/maps?q="+latitude+","+longitude;
   
   
    $('.location-name').text(title);
   
    $('.location-address').text(parked_address);
   
    $('.location-distance').text(count_miles);
   
    $('.pickup-date-time').text(label_value);
   
    $('.location-direction').attr('href',direction_url);
   
   
   

    //alert(title+parked_address+label_value+count_miles+latitude+longitude);
   
     $('.custom-cart-popup-main').css('display','block');
   
    $('body').addClass('cart-popup-open');
     
   } else {
   	   $( "#dialog" ).dialog();
   //	alert('Please select the option!');
   }
    
    });
</script>

<script>
 $( ".outer-data" ).on("click","li.list_click", function(event) {    
       //aert($(this).attr("data-attr-id"));
         
    $(this).find('.open_list').css("display", "block");
          
   });
</script>




<script type="text/javascript">
  function initAutocomplete()
  {
    autocomplete = new google.maps.places.Autocomplete((document.getElementById('location')),{types: ['geocode']});
    autocomplete.addListener('place_changed', fillInAddress);
  }

  function fillInAddress()
  {
    var place = autocomplete.getPlace();
    var latitude = place.geometry.location.lat();
    var longitude = place.geometry.location.lng();
    $('#latitude').val(latitude);
    $('#longitude').val(longitude);
  }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD0BEltumBd3qxNjIzVwZ7nAIHEhcKfHug&v=3.exp&sensor=false&callback=initialize"></script>

<script type="text/javascript">
function initMap()
{
     //var locationsJSON = [];
// {lat: 31.564614,lon: 74.298718}, 
// {lat: 31.563892,lon: 74.300435}, 
// {lat: 31.565546,lon: 74.297597}, 
// {lat: 31.565332,lon: 74.296744}, 
// {lat: 31.565332,lon: 74.296744}, 
// {lat: 31.565272,lon: 74.297637}, 
// {lat: 31.562347,lon: 74.296712}];

  
  var input = document.getElementById('location');
  
  if($(input).val() == ''){
        $(".locate_list").css("display", "block");
  }
    



 var searchName = new google.maps.places.SearchBox(input);
  searchName.addListener('places_changed', function() {
          $(".locate_list").css("display", "none");


    var places = searchName.getPlaces();

     for(i=0; i < places.length; i++){
        for(var j=0;j < places[i].address_components.length; j++){
          for(var k=0; k < places[i].address_components[j].types.length; k++){
            if(places[i].address_components[j].types[k] == "postal_code" || places[i].address_components[j].types[k] == "locality"){
              zip_code = places[i].address_components[j].short_name;
             
              $.ajax({
            type:'POST',
            url:'https://tourtheappletruck.com/api/get_data.php',
            dataType: "json",
            data:{zip_code:zip_code},
            success:function(response){   

              var len = response.length;
              $('.Results').text(len+'Results');
            	for(var i=0; i<len; i++){
                  
                 var outer_status = response[i].status;
                  
                  
                var id = response[i].id;
                var location = response[i].location;
              
              	var date_text = response[i].date_text;
                var current_date_text = date_text.split(",");
                var  date_text_count =  current_date_text.length;
                  
             
                var address = response[i].address;
                var pick_up_date = response[i].pick_up_date; 

                var current_pick_date = pick_up_date.split(",");
                var  count =  current_pick_date.length;
      
                var start_time = response[i].start_time;
              
                var current_start_time = start_time.split(",");
                var  count_time =  current_start_time.length;
              
            
              
              
                var end_time = response[i].end_time;
              
                var current_end_time = end_time.split(",");
                var count_end_time =  current_end_time.length;
                  
                 var check_status = response[i].check_status;
                 var current_check_status = check_status.split(",");
                 var  current_check_status_count =  current_check_status.length;
                  
              
                var latitude = response[i].latitude;
                var longitude = response[i].longitude;
                  
                 var lat2 = $('#current_lat').val();
                 var lon2 = $('#current_long').val();
             
                 var radlat1 = Math.PI * latitude/180;
                 var radlat2 = Math.PI * lat2/180;
                 var theta = longitude-lon2;
                 var radtheta = Math.PI * theta/180;
                 var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);

                 if (dist > 1) {
                   dist = 1;
                 }
                 dist = Math.acos(dist);
                 dist = dist * 180/Math.PI;
                 dist = dist * 60 * 1.1515;

                 var miles = dist.toFixed(1);
                //var miles = response[i].miles;

                 var test11 ='<span class="pick-up-date-text">Choose Your Pickup Date</span>';
              
        var test = "<li class='list_click "+location.replace(/[^A-Z0-9]/ig, "")+"' data-attr-id='"+id+"'>"+
                 "<input type='hidden' value='"+latitude+"' name='latitude' class='latitude_value'>"+
                "<input type='hidden' value='"+longitude+"' name ='longitude'  class='longitude_value'>"+
                "<div class='list_inner'><h3><b>"+location+"</b></h3><p class='count_miles'>"+miles+"&nbsp;miles from you</p></div>"+
                "<span class='parked_address'><i class='fa fa-map-marker'></i>"+address+"</span>"+
        "<div class='open_list' data-attr-id='"+id+"'>";
              
                var result = "";
                for(var j=0; j<count;j++){
                  
                  for(var k=0; k<count_time;k++){
                    
                    for(var m=0; m<count_end_time;m++){
                   
                   for(var n=0; n<date_text_count;n++){
                     
                     for(var p=0; p<current_check_status_count;p++){
                  			
                      
                       if(j == k && j==m && j==n && j==p ){ 
                       
                      var format_current_pick_date =  moment(current_pick_date[j], "YYYY-MM-DD").format("MM/DD/YYYY");

//                       var today = new Date();
//                       var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();

//                       var modify_date = moment(date, "YYYY-MM-DD").format("MM/DD/YYYY");


                      if(current_check_status[p] == "active") {
						
						
               				 result+="<div class='radio_btn Secoend'>"+
                          "<label>"+
                          "<input type='radio' id='html' name='leaflet-base-layers' value='HTML' class='leaflet-control-layers-selector'>"+
                          "<span class='current_pick_date_time'>"+format_current_pick_date+"&nbsp;|&nbsp;"+current_start_time[k]+"&nbsp;"+current_end_time[m]+"</span>"+
                          "<span class='pop-up-date' style='display:none'>"+format_current_pick_date+" | "+current_start_time[k]+" - "+current_end_time[m]+"</span>"+
							"<h5 class='selected_disabled_text'>"+current_date_text[n]+"</h5>"+
                        

                          "</label>"+
                          "</div>"; 



                        } else {
							
                          if(date_text == "") {
                           var date_text ="PRE-ORDER NO LONGER AVAILABLE!";
                          } else {
                           var date_text = date_text;
                          }
                          
                             result+="<div class='radio_btn Secoend'>"+
                        "<label>"+
                        "<input disabled type='radio' id='html' name='leaflet-base-layers' value='HTML' class='leaflet-control-layers-selector'>"+
                        "<span class='current_pick_date_time'>"+'<span style="text-decoration-line: line-through;">'+format_current_pick_date+'</span>'+"&nbsp;|&nbsp;"+'<span style="text-decoration-line: line-through;">'+current_start_time[k]+"&nbsp;"+current_end_time[m]+'</span>'+"</span>"+
                        "<span class='pop-up-date' style='display:none'>"+format_current_pick_date+" | "+current_start_time[k]+" - "+current_end_time[m]+"</span>"+
                         "<h5 class='selected_disabled_text'>"+current_date_text[n]+"</h5>"+
                      


                        "</label>"+
                        "</div>"; 
                        
                        }
                      }
                    }
                    }
                   }
                 }
               }
               
                var test2= "<div class='test'><a class='pick_product' id='pickbt'><i class='fa fa-shopping'></i>PICK YOUR PRODUCTS</a></div>";
        
        "</div>"+
        "</li>";
//                  $('.outer-data').empty();
//                $('.Results').empty();
                  if(outer_status=="Active") {
                  	$(".outer-data").html(test+test11+result+test2);
                  } else {
                     $(".outer-data").html(test+test11+result+test2);
                      $('.open_list').addClass('disabled');
                 	 $(".open_list  *").attr("disabled", "disabled").off('click');
                  }
                 
           }
            }

           }); 
              
             }
           }
          }
         }
    
      if (places.length == 0) {
        return;
      }
     markers.forEach((marker) => {
      marker.setMap(null);
    });
    markers = [];
    const bounds = new google.maps.LatLngBounds();
    
        places.forEach((place) => {
      if (!place.geometry || !place.geometry.location) {
        console.log("Returned place contains no geometry");
        return;
      }
      const icon = {
        url: 'https://cdn.shopify.com/s/files/1/0564/3141/1394/files/mrk.png?v=1627993768',
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25),
      };
      // Create a marker for each place.
      markers.push(
        new google.maps.Marker({
           map,
          icon,
          title: place.name,
          position: place.geometry.location,
        })
      );

      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);


     });

                        
                        
  var getData;
    $.ajax({
          'async': false,
          'global': false,
            type:'get',
            url:'https://tourtheappletruck.com/api/get_record.php',
            dataType: "json",
            success:function(response){ 
                 getData = response;
                // alert(JSON.stringify(response));
               // locationsJSON.push({'lat':latitude,'lon':longitude})  
           }
    });
   // alert(JSON.stringify(getData));
  //alert(JSON.stringify(locationsJSON));
var locations = getData;
  //alert(JSON.stringify(locations));
var map = new google.maps.Map(document.getElementById('mapCanvas'), {
  zoom: 10,
  center: new google.maps.LatLng(31.5546, 74.3572),
  mapTypeId: google.maps.MapTypeId.ROADMAP
});
  map.addListener("bounds_changed", () => {
                  searchBox.setBounds(map.getBounds());
});
  let markers = [];
var geocoder = new google.maps.Geocoder();
var infowindow = new google.maps.InfoWindow();
  
document.getElementById("submit").addEventListener("click", () => {

  if (navigator.geolocation) {

  navigator.geolocation.getCurrentPosition(function (position) {

    var pos = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
    

    // Create a marker and center map on user location
    marker = new google.maps.Marker({
      position: pos,
     // draggable: true,
     // animation: google.maps.Animation.DROP,
      map: map,
      icon:'https://cdn.shopify.com/s/files/1/0564/3141/1394/files/Loction-Marker.png?v=1626856192'
    });

    map.setCenter(pos);
  });
}       

     //geocodeLatLng(geocoder, map, infowindow);
      //alert('test');
  },{ once: true });
  
  
  if (navigator.geolocation) {

  navigator.geolocation.getCurrentPosition(function (position) {

    var pos = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

      var current_latitude = position.coords.latitude;
      var current_longitude = position.coords.longitude;

      $('#current_lat').val(current_latitude);
	  $('#current_long').val(current_longitude);

    // Create a marker and center map on user location
    marker = new google.maps.Marker({
      position: pos,
      //draggable: true,
      //animation: google.maps.Animation.DROP,
       map: map,
      zoom: 15,
      icon:'https://cdn.shopify.com/s/files/1/0564/3141/1394/files/mrk.png?v=1627993768'
    });

    map.setCenter(pos);
  });
}       
  
  
  function geocodeLatLng(geocoder, map, infowindow) {
  const input = document.getElementById("latlng").value;
  const latlngStr = input.split(",", 2);
  const latlng = {
    lat: parseFloat(latlngStr[0]),
    lng: parseFloat(latlngStr[1]),
  };
  geocoder
    .geocode({ location: latlng })
    .then((response) => {
      if (response.results[0]) {
        map.setZoom(11);
        const marker = new google.maps.Marker({
          position: latlng,
          map: map,
        });
        infowindow.setContent(response.results[0].formatted_address);
        infowindow.open(map, marker);
      } else {
        window.alert("No results found");
      }
    })
    .catch((e) => window.alert("Geocoder failed due to: " + e));
}

var marker, i;

for (i = 0; i < locations.length; i++) {
  var myLatLng = new google.maps.LatLng(locations[i].lat, locations[i].lon);
  marker = new google.maps.Marker({
  position: myLatLng,
  map: map,
    html:locations[i].location,
    icon:'https://cdn.shopify.com/s/files/1/0564/3141/1394/files/Loction-Marker.png?v=1626856192'

  });
  
//  marker.setAnimation(google.maps.Animation.BOUNCE);
  
  
    $( ".outer-data" ).on("click",".list_click", function(event) {    
       var markerId = $(this).attr('data-attr-id');
              // alert(markerId);
      var result = $.grep(marker, function (e) {
              //alert(result);
              
        if (e.id == markerId) {
          return e;
        }
      });
       //google.maps.event.trigger(result[0].marker, 'click');
    });
	map.setCenter(myLatLng);
  google.maps.event.addListener(marker, 'click', function(evt) {
  var mark = this;
    
    
     $(document).ready(function(){
      var name = mark.html.replace(/\s/g,'');
      var api_get_name = mark.html;
      console.log(name)
      
    $.ajax({
    type:'POST',
    url:'https://tourtheappletruck.com/api/get_single_record.php',
    dataType: "json",
    data:{api_get_name:api_get_name},
    success:function(response) {  
      
              var len = response.length;
              $('.Results').text(len+'Results');
             for(var i=0; i<len; i++){
                 $(".locate_list").css("display", "none");
               
                var outer_status = response[i].status;
                var id = response[i].id;
                var location = response[i].location;
         		var remove_spaces = location.replace(/\s/g,'');
                
                var date_text = response[i].date_text;
                var current_date_text = date_text.split(",");
                var  date_text_count =  current_date_text.length;
               
                var address = response[i].address;
                var pick_up_date = response[i].pick_up_date; 

                var current_pick_date = pick_up_date.split(",");
                var  count =  current_pick_date.length;
      
                var start_time = response[i].start_time;
              
                var current_start_time = start_time.split(",");
                var  count_time =  current_start_time.length;
              
            
              
              
                var end_time = response[i].end_time;
              
                var current_end_time = end_time.split(",");
                var count_end_time =  current_end_time.length;
               
               var check_status = response[i].check_status;
               var current_check_status = check_status.split(",");
               var  current_check_status_count =  current_check_status.length;
              
                var latitude = response[i].latitude;
                var longitude = response[i].longitude;
               
                var lat2 = $('#current_lat').val();
                  var lon2 = $('#current_long').val();

               var radlat1 = Math.PI * latitude/180;
               var radlat2 = Math.PI * lat2/180;
               var theta = longitude-lon2;
               var radtheta = Math.PI * theta/180;
               var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);

               if (dist > 1) {
                 dist = 1;
               }
               dist = Math.acos(dist);
               dist = dist * 180/Math.PI;
               dist = dist * 60 * 1.1515;

               var miles = dist.toFixed(1); 
               // var miles = response[i].miles;
                                
                var test =  "<li class='list_click "+location.replace(/[^A-Z0-9]/ig, "")+"' data-attr-id='"+id+"'>"+
                         "<input type='hidden' value='"+latitude+"' name='latitude' class='latitude_value'>"+
                        "<input type='hidden' value='"+longitude+"' name ='longitude'  class='longitude_value'>"+
                        "<div class='list_inner'><h3><b>"+location+"</b></h3><p class='count_miles'>"+miles+"&nbsp;miles from you</p></div>"+
                        "<span class='parked_address'><i class='fa fa-map-marker'></i>"+address+"</span>"+
                "<div class='open_list' data-attr-id='"+id+"'>";

                var test11 ='<span class="pick-up-date-text">Choose Your Pickup Date</span>';
              
                var result = "";
                for(var j=0; j<count;j++){
                  
                  for(var k=0; k<count_time;k++){
                    
                    for(var m=0; m<count_end_time;m++){
                      
                       for(var n=0; n<date_text_count;n++){
                     
                          for(var p=0; p<current_check_status_count;p++){
                   
                  
                  
                    if(j == k && j==m && j==n && j==p ){ 
                      
                      var format_current_pick_date =  moment(current_pick_date[j], "YYYY-MM-DD").format("MM/DD/YYYY");

//                     var today = new Date();
//                     var _current_date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();

//                     var modify_date = moment(_current_date, "YYYY-MM-DD").format("MM/DD/YYYY");

                    if(current_check_status[p] == "active") {

                        

                      result+="<div class='radio_btn Secoend'>"+
                        "<label>"+
                        "<input type='radio' id='html' name='leaflet-base-layers' value='HTML' class='leaflet-control-layers-selector'>"+
                        "<span class='current_pick_date_time'>"+format_current_pick_date+"&nbsp;|&nbsp;"+current_start_time[k]+"&nbsp;"+current_end_time[m]+"</span>"+
                        "<span class='pop-up-date' style='display:none'>"+format_current_pick_date+" | "+current_start_time[k]+" - "+current_end_time[m]+"</span>"+
                        "<h5 class='selected_disabled_text'>"+current_date_text[n]+"</h5>"+
                        

                        "</label>"+
                        "</div>"; 


                      } else {
							

                        if(date_text == "") {
                          var date_text ="PRE-ORDER NO LONGER AVAILABLE!";
                        } else {
                          var date_text = date_text;
                        }
                        
                        result+="<div class='radio_btn Secoend'>"+
                          "<label>"+
                          "<input disabled type='radio' id='html' name='leaflet-base-layers' value='HTML' class='leaflet-control-layers-selector'>"+
                          "<span class='current_pick_date_time'>"+'<span style="text-decoration-line: line-through;">'+format_current_pick_date+'</span>'+"&nbsp;|&nbsp;"+'<span style="text-decoration-line: line-through;">'+current_start_time[k]+"&nbsp;"+current_end_time[m]+'</span>'+"</span>"+
                          "<span class='pop-up-date' style='display:none'>"+format_current_pick_date+" | "+current_start_time[k]+" - "+current_end_time[m]+"</span>"+
                          "<h5 class='selected_disabled_text'>"+current_date_text[n]+"</h5>"+
                       


                          "</label>"+
                          "</div>"; 
                         
                      }
                    }
                          }
                       }
                    
                   }
                 }
               }
            
        var test2= "<div class='test'><a class='pick_product' id='pickbt'><i class='fa fa-shopping'></i>PICK YOUR PRODUCTS</a></div>";
        
        "</div>"+
        "</li>";
//                  $('.outer-data').empty();
//                $('.Results').empty();
		
                if(outer_status=="Active") {
                  	$(".outer-data").html(test+test11+result+test2);
                    var list_click = $("ul.outer-data li").find(".open_list").css('display','block');
                  } else {
                     $(".outer-data").html(test+test11+result+test2);
                      $('.open_list').addClass('disabled');
                 	 $(".open_list  *").attr("disabled", "disabled").off('click');
                     var list_click = $("ul.outer-data li").find(".open_list").css('display','block');
                  }
              
               

           }
          

      }
    }); 
      
    });
    
    
  geocoder.geocode({
    location: evt.latLng
  }, function(results, status) {
    if (status == "OK") {
    infowindow.setContent('<h5>'+mark.html+'</h5>'+"<br>"+'<p>'+results[0].formatted_address+'</p>');
    infowindow.open(map, mark);
    }
  });
  });
};
}
google.maps.event.addDomListener(window, "load", initMap);
$(document).ready(function() { 
function getLocation()
{
  if (navigator.geolocation)
  {
    navigator.geolocation.getCurrentPosition(showPosition);
  }
  else 
  { 
    alert("Geolocation is not supported by this browser.");
  }
}
function showPosition(position)
{
  $('#latitude').val(position.coords.latitude);
  $('#longitude').val(position.coords.longitude);
}
});
</script>



<script>
  
  
  $('.custom-cart-close').click(function(){
  
  
     $('.custom-cart-popup-main').css('display','none');
    $('body').removeClass('cart-popup-open');
   
  });
  
  
  $('#first-email').keyup(function(){
  
    var first_email_val = $('#first-email').val();
    
    var confirmation_email_val = $('#confirmation-email').val();
  
    if(first_email_val != confirmation_email_val)
    {
    
      $('.email-error').show();
    
    }
    else
    {
    
      $('.email-error').hide();
    }
  
  });
  
  $('#confirmation-email').keyup(function(){
  
    var first_email_val = $('#first-email').val();
    
    var confirmation_email_val = $('#confirmation-email').val();
  
    if(first_email_val != confirmation_email_val)
    {
    
      $('.email-error').show();
    
    }
    else
    {
    
      $('.email-error').hide();
    }
  
  });
  
  
  $('.checkout-btn').click(function(){
    
       
    var first_email_val = $('#first-email').val();
    
    var confirmation_email_val = $('#confirmation-email').val();
    
    var location_title = $('.location-name').text();
    
    var location = $('.location-address').text();
    
    var pickup_date = $('.pickup-date-time').text();
     
    
    if($('#agree').prop("checked") == false)
    {
      
      $('.error-popup-main').css('display','block');
      
      $('.agree-error-section').css('display','block');
      
      $('.email-error-section').css('display','none');
      
      $('body').addClass('open-eror-popup');
                
    }
    else if((first_email_val != confirmation_email_val) || first_email_val == '' || confirmation_email_val == '')
    {
    
      $('.error-popup-main').css('display','block');
      
        $('.agree-error-section').css('display','none');
      
        $('.email-error-section').css('display','block');
      
        $('body').addClass('open-eror-popup');
    
    }
    else
    {
      
      var prod_array = new Array();
            
      $('.product-list-item').each(function(){
      
        var item={};
        
        var variant_id = $(this).attr('data-id');
        
        var quantity = $('input',this).val();
        
        item ["quantity"] = quantity;
        
        item ["id"] = variant_id;
        
        prod_array.push(item);
                  
      });
      
      var carray = {
      
        "attributes":{
      
          "order-type":"preorder",
          "location":location_title,
          "address":location,
          "picup_date":pickup_date
            
        }
      }
                  
      addItemToCart(prod_array, first_email_val, carray);
            
    }
    
  });
  
  
  $('.error-popup-close').click(function(){
  
  
      $('.error-popup-main').css('display','none');
      $('body').removeClass('open-eror-popup');
  
  });
  
  $('.confirm-btn').click(function(){
    
      $('.error-popup-main').css('display','none');
      $('body').removeClass('open-eror-popup');
  
  });
  
function addItemToCart(items, cmail, cart_attributes) {
           
  jQuery.ajax({
    type: 'POST',
    url: '/cart/add.js',
    data: {items:items},
    dataType: 'json',
    success: function() { 
      
     addCartAttributes(cart_attributes, cmail);
     

    },
    error: function(error) {alert(error.responseJSON.message);}
  });
}
  
 function addCartAttributes(cattributes, chmail) {
           
  jQuery.ajax({
    type: 'POST',
    url: '/cart/update.js',
    data: cattributes,
    dataType: 'json',
    success: function() { 
      
      window.location.href='/checkout?checkout[email]=' + chmail ;
     

    },
    error: function(error) {alert(error.responseJSON.message);}
  });

}  
    
    
</script>



{% schema %}
  {
    "name": "Section name",
    "settings": [

    {
      "type":"text",
      "id":"step-two-heading",
      "label":"Step two heading"

    },
    {
      "type":"text",
      "id":"product-section-heading",
      "label":"Product section heading"

    },
    {
      "type":"text",
      "id":"detail-section-heading",
      "label":"Detail section heading"

    },
    {
      "type":"text",
      "id":"location-heading",
      "label":"Location heading"
    },
    {
      "type":"text",
      "id":"pickup-date-heading",
      "label":"Pickup date heading"
    },
    {
      "type":"text",
      "id":"email-error-message",
      "label":"Email error message"
    },
    {
      "type":"text",
      "id":"agree-text",
      "label":"Agree checkbox text"
    },
    {
      "type":"text",
      "id":"cart-subtotal-text",
      "label":"Cart subtotal text"
    },
    {
      "type":"text",
      "id":"checkout-btn-text",
      "label":"Checkout button label"
    },
    {
      "type":"text",
      "id":"email-error-popup-message",
      "label":"Email error popup message"
    },
    {
      "type":"text",
      "id":"agree-error-popup-message",
      "label":"Agree error popup message"
    }
  ],
  "blocks":[

    {
      "type":"cart-product",
      "name":"Cart product",
      "settings":[

        {
          "type":"product",
          "id":"cart-product",
          "label":"Product"
        }

      ]


    }

  ]
  }
{% endschema %}

{% stylesheet %}
{% endstylesheet %}

{% javascript %}
{% endjavascript %}
