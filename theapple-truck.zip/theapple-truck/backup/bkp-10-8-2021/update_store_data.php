<?php 
    require_once("config.php");

    if(isset($_POST["update_data"])) {
 
        
        $id = $_POST['id'];
        //$store_id = $_POST['store_id'];
        //$pin_code = $_POST['pin_code'];
        //$store_name = $_POST['store_name'];
        
        $location = $_POST["location"];
        
        
        $pickup_date =   implode(',',$_POST['pickup_date']);
        $new_pickup_date =  explode(",",$pickup_date);
        
        $saved_pickup_date = "";
        for($i=0;$i<count($new_pickup_date);$i++){
        
        $saved_pickup_date.= $new_pickup_date[$i].',';
        
        }
        
        $trim_pickup_date = trim($saved_pickup_date, ",");
        
        
         $start_time  = implode(',',$_POST['pickup_start_time']);

        $new_start_time =  explode(",",$start_time);
        
        $saved_current_start_time = "";
        
        for($i=0;$i<count($new_start_time);$i++){
        
        
        $saved_current_start_time.= date('h:i A', strtotime($new_start_time[$i])).',';
        }
        
        $trim_saved_current_start_time  = trim($saved_current_start_time, ",");
        
        
        
        $end_time  = implode(',',$_POST['pickup_end_time']);
        
        $new_end_time =  explode(",",$end_time);
        
        
        
        $saved_current_end_time = "";
        for($i=0;$i<count($new_end_time);$i++){
        
        
        $saved_current_end_time.= date('h:i A', strtotime($new_end_time[$i])).',';
        }
        $trim_current_end_time = trim($saved_current_end_time, ",");
        
        
        
        $check_status = implode(',',$_POST['selection']);
        $date_text = implode(',',$_POST['date_text']);
        $address = $_POST["address"];
        $city = $_POST["city"];
        $state = $_POST["state"];
        $zip = $_POST["zip"];
        //$latitude = $_POST["latitude"];
        //$longitude = $_POST["longitude"];
        
        $status = $_POST["status"];


        
         $sql = "UPDATE store_data SET location='$location',store_current_date='$trim_pickup_date',start_time='$trim_saved_current_start_time',end_time='$trim_current_end_time',check_status='$check_status',date_text='$date_text',address='$address',city='$city',state='$state',pin_code='$zip',status='$status' WHERE id=$id";
        
        $record = $conn->query($sql);
        header('location:home.php?update_data_success=updated_data_successfully');
        
    }


?>