<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
 <script src="https://weareoutman.github.io/clockpicker/dist/jquery-clockpicker.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js" type="text/javascript"></script>

<script>

// $(document).ready(function() {    
//  $(".delete").click(function(){  
//     alert('test'); 
//  });
// }); 

    
$(function() {
      $( 'ul.nav li' ).on( 'click', function() {
            $( this ).parent().find( 'li.active' ).removeClass( 'active' );
            $( this ).addClass( 'active' );
      });
});

 $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
        
         $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4'
        });
        
    var input = $('#input-a');
        input.clockpicker({
        autoclose: true
    });
    
     var input = $('#input-b');
        input.clockpicker({
        autoclose: true
    });

// Manual operations
$('#button-a').click(function(e){
    // Have to stop propagation here
    e.stopPropagation();
    input.clockpicker('show')
            .clockpicker('toggleView', 'minutes');
});
$('#button-b').click(function(e){
    // Have to stop propagation here
    e.stopPropagation();
    input.clockpicker('show')
            .clockpicker('toggleView', 'hours');
});

$(document).ready(function () {
            $('#dtBasicExample').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });

</script>
