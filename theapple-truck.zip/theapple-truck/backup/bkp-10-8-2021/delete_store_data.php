<?php
    
include_once 'config.php';
$sql = "DELETE FROM store_data WHERE id='" . $_GET["userid"] . "'";
if (mysqli_query($conn, $sql)) {
        header('location:home.php?Delete_store_status=delete_store_data');
        exit;
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);

?>