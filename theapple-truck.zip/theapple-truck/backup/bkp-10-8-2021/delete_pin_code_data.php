<?php
    
include_once 'config.php';
$sql = "DELETE FROM store_pin_code WHERE id='" . $_GET["pin_code_id"] . "'";
if (mysqli_query($conn, $sql)) {
        header('location:add_store.php?delete_store_data_status=delete_store_data');
        exit;
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);

?>