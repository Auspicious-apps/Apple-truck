<?php 

// Data base
require_once("config.php");

//$store_id = $_POST["store_id"];
//$pin_code = $_POST["pin_code"];
//$store_name = $_POST["store_name"];

$latitude = $_POST["latitude"];
$longitude = $_POST["longitude"];

$current_latitude = '39.4848';
$current_longitude = '88.3416';

// calcualte start miles 

$theta = $longitude - $current_longitude;
$dist = sin(deg2rad($latitude)) * sin(deg2rad($current_latitude)) +  cos(deg2rad($latitude)) * cos(deg2rad($current_latitude)) * cos(deg2rad($theta));
$dist = acos($dist);
$dist = rad2deg($dist);
$miles = $dist * 60 * 1.1515;

$calculate_total_midles = $miles * 1.609344;
$total_midles = number_format($calculate_total_midles, 1);
    

    


// end miles 

$location = $_POST["location"];
$date = $_POST["date"];
//$sart_time = $_POST["start_time"];
        
        
        
        $pickup_date =   implode(',',$_POST['pickup_date']);
        $new_pickup_date =  explode(",",$pickup_date);
        
         $saved_pickup_date = "";
            for($i=0;$i<count($new_pickup_date);$i++){
            
            $saved_pickup_date.= $new_pickup_date[$i].',';
        
        }
        
        $trim_pickup_date = trim($saved_pickup_date, ",");
        
            
// $the_time = date('h:i A', strtotime($_POST['pickup_start_time']));
// die($the_time);

            
// $array =[];

// for($i=0;$i<=count($pickup_date);$i++){
//     $array = date('h:i A', strtotime($pickup_date[$i]));
    
// }
// die($array);
    $start_time  = implode(',',$_POST['pickup_start_time']);

    $new_start_time =  explode(",",$start_time);
    
    $saved_current_start_time = "";

    for($i=0;$i<count($new_start_time);$i++){
    
        
        $saved_current_start_time.= date('h:i A', strtotime($new_start_time[$i])).',';
     }
            
    $trim_saved_current_start_time  = trim($saved_current_start_time, ",");
    
    

$end_time  = implode(',',$_POST['pickup_end_time']);

$new_end_time =  explode(",",$end_time);



 $saved_current_end_time = "";
    for($i=0;$i<count($new_end_time);$i++){
    
        
        $saved_current_end_time.= date('h:i A', strtotime($new_end_time[$i])).',';
     }
    $trim_current_end_time = trim($saved_current_end_time, ",");
    



//$start_time_meridian = $_POST["start_time_meridian"];


//$end_time = $_POST["end_time"];
//$end_time_meridian = $_POST["end_time_meridian"];
$check_status =  implode(',',$_POST["selection"]);

$date_text = implode(',',$_POST["date_text"]);
$address = $_POST["address"];
$city = $_POST["city"];
$state = $_POST["state"];
$zip = $_POST["zip"];
//$latitude = $_POST["latitude"];
//$longitude = $_POST["longitude"];

$status = $_POST["status"];

$created_at = date('Y-m-d H:i:s');




//$check_sql = "SELECT store_id FROM store_data where
//pin_code='$pin_code'";

//$result = $conn->query($check_sql);

//$row = $result->fetch_assoc();

 //$check_size = $row['pin_code'];
 
 
 if(!empty($zip)){
     
      $sql = "INSERT INTO store_data (latitude,longitude,location,store_current_date,start_time,end_time,check_status,date_text,address,city,state,pin_code,miles,status,created_at)
    VALUES ('$latitude','$longitude','$location','$trim_pickup_date','$trim_saved_current_start_time','$trim_current_end_time','$check_status','$date_text','$address','$city','$state','$zip','$total_midles','$status','$created_at')";
    
    if (mysqli_query($conn, $sql)) {

        header('location:add_store.php?save_store_status=success');

        exit;
    
    } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    mysqli_close($conn);

 } else {
    
     header('location:add_store.php?status=error');
     exit;
     

 }
?>