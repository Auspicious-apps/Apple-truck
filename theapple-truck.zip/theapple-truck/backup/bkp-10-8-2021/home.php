<?php
// Get our helper functions
require_once("inc/functions.php");
require_once("config.php");

ini_set('display_errors', 1);

$shop = $_GET['shop'];
$shop = "the-apple-truck";
$token = "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";
$query = array(
  "Content-type" => "application/json" // Tell Shopify that we're expecting a response in JSON format
);

// Run API call to get products
$products = shopify_call($token, $shop, "/admin/products.json", array(), 'GET');

// Convert product JSON information into an array
$products = json_decode($products['response'], TRUE);
// echo "<pre>";
// print_r($products);
// die;

// // Get the ID of the first product
// $product_id = $products['products'][0]['id'];

// // Modify product data
// $modify_data = array(
//  "product" => array(
//    "id" => $product_id,
//    "title" => "My New Title"
//  )
// );

// // Run API call to modify the product
// $modified_product = shopify_call($token, $shop, "/admin/products/" . $product_id . ".json", $modify_data, 'PUT');

// // Storage response
// $modified_product_response = $modified_product['response'];

?>
<!DOCTYPE html>
<html>
    <style>
        .badge.badge-success {
    background-color: green !important;
}
    </style>
    <?php
     
    require 'layouts/header.php';  ?>
    <link rel="stylesheet" href="layouts/custom.css">
    
    <?php  require 'layouts/nav_bar.php';  ?>
    <body>
        <div class="container">
        
        <div class="row">
        <div class="col-sm-10">
        <?php 
        if( $_GET['Delete_store_status'] == 'delete_store_data') { ?>
            
            <div class="alert alert-danger"> Your Data has been Deleted successfully!</div>
        <?php } ?>
        
        <?php 
        if( $_GET['update_data_success'] == 'updated_data_successfully') { ?>
            
            <div class="alert alert-success"> Your Data has been Updated successfully!</div>
        <?php } ?>
        
        </div>
    </div>
    
      <h3 class="text-center">Welcome To The Apple Truck Dashboard </h3>
      <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Sr.No.

      </th>
      <!--<th class="th-sm">Store ID-->

      <!--</th>-->
      <th class="th-sm">Zip Code

      </th>
      <!--<th class="th-sm">Store Name-->

      <!--</th>-->
      <th class="th-sm">Location

      </th>
      <th class="th-sm">Date

      </th>
      <th class="th-sm">Start Time  
      
      </th>
        <th class="th-sm">End Time  
      
      </th>
       
       <th class="th-sm">Date text  
      
      </th>
      
        <th class="th-sm">Address  
      
      </th>
      
        <th class="th-sm">City  
      
        </th>
        
        <th class="th-sm">State  
      
        </th>
      
      <!--  <th class="th-sm">Latitude  -->
      
      <!--</th>-->
      <!--  <th class="th-sm">Longitude  -->
      
      <!--</th>-->
       <th class="th-sm">status  
      
      </th>
      <!-- <th class="th-sm">Created At  -->
      
      <!--</th>-->
       <th class="th-sm">Action  
      
      </th>
    </tr>
  </thead>
  <tbody>
    <?php  
        $sql = "SELECT *  FROM store_data";
        $get_data = $conn->query($sql);
        $i=1;
        while($get_all_data = $get_data->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $i; ?></td>
        <!--<td><?php // echo $get_all_data["store_id"]; ?></td>-->
        <td><?php echo $get_all_data["pin_code"]; ?></td>
        <!--<td><?php// echo $get_all_data["store_name"]; ?></td>-->
        <td><?php echo $get_all_data["location"]; ?></td>
        <td><?php echo $get_all_data["store_current_date"];?></td>
        <td><?php echo $get_all_data["start_time"]; ?>&nbsp; <?php echo $get_all_data["start_time_meridian"]; ?></td> 
        <td><?php echo $get_all_data["end_time"];?>&nbsp;<?php echo $get_all_data["end_time_meridian"]; ?></td> 
        <td><?php echo $get_all_data["date_text"];?></td> 
        <td><?php echo $get_all_data["address"];?></td> 
        <td><?php echo $get_all_data["city"];?></td>
        <td><?php echo $get_all_data["state"];?></td>
        <!--<td><?php // echo $get_all_data["latitude"];?></td> 
        <td><?php //echo $get_all_data["longitude"];?></td>-->
        <td><?php if($get_all_data["status"]=='Active') { ?>
	 		<span class="badge badge-success">Active</span>
        <?php } else { ?>
            <span class="badge badge-pill badge-warning">Inactive</span>
	 	<?php  } ?></td>
       
        <td><a  href="delete_store_data.php?userid=<?php echo $get_all_data["id"]; ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>&nbsp;&nbsp;<a href="edit_store_data.php?edit_store_data=<?php echo $get_all_data['id']; ?>" class="edit_btn" >Edit</a></td>
        
        <!--<td><button type="button" class="delete">test</button></td>-->
    </tr>
    <?php $i++;} ?>
  
  </tbody>
  <tfoot>
    
    <tr>
    <th class="th-sm">Sr.No.
    
    </th>
    <!--<th class="th-sm">Store ID-->
    
    <!--</th>-->
     <th class="th-sm">Zip Code

      </th>
    <!--<th class="th-sm">Store Name-->

    <!--</th>-->
    <th class="th-sm">Location

    </th>
      <th class="th-sm">Date

      </th>
      <th class="th-sm">Start Time  
      
      </th>
        <th class="th-sm">End Time  
      
      </th>
        
        <th class="th-sm">Date Text  
        
        </th>
      
        <th class="th-sm">Address  
      
      </th>
      
        <th class="th-sm">City  
      
        </th>
        
        <th class="th-sm">State
        
        </th>  
     
        
      <!--  <th class="th-sm">Latitude  -->
      
      <!--</th>-->
      <!--  <th class="th-sm">Longitude  -->
      
      <!--</th>-->
       <th class="th-sm">status  
      
      </th>
      <!-- <th class="th-sm">Created At  -->
      
      <!--</th>-->
       <th class="th-sm">Action  
      
      </th>
    </tr>
    
  </tfoot>
</table>
    
      <?php require 'layouts/footer.php';  ?>
     </div>
    </body>
</html>
