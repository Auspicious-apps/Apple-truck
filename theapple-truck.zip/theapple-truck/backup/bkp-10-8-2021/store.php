<!DOCTYPE html>
<html>
<head>
	<title>Add Store</title>
<!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
</head>
<body>
<div class="container">
<form>
    
    <div class="form-group row">
    <label for="pin_code" class="col-sm-2 col-form-label">Pin Code:</label>
    <div class="col-sm-10">
      <select class="form-select pin_code" aria-label="Default select example">
        <option selected>Select Option</option>
        <option value="1100">1100</option>
        <option value="1210">1210</option>
        <option value="6852">6852</option>
        <option value="1310">1310</option>
        
    </select>
    </div>
    </div>
  
  <div class="form-group row">
    <label for="store_name" class="col-sm-2 col-form-label">Store Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="store_name" placeholder="Enter your store">
    </div>
  </div>
  <div class="form-group row">
    <label for="location" class="col-sm-2 col-form-label"> Location: </label>
    <div class="col-sm-2">
      <input type="location" class="form-control" id="location" placeholder="Enter your location">
    </div>
    
    <label for="start_date" class="col-sm-2"> Date: </label>
    <div class="col-sm-2">
      <input id="datepicker" class="date" name="date"/>
    </div>
    
 <label for="start_time" class="col-sm-2 col-form-label"> Start time: </label>
    <div class="col-sm-2">
      <input id="datepicker1" class="start_time" name="start_time"/>
    </div>
  </div>
  
   <div class="form-group row">
    <label for="latitude" class="col-sm-2 col-form-label"> Latitude: </label>
    <div class="col-sm-10">
      <input type="latitude" class="form-control" id="latitude" placeholder="Enter your latitude">
    </div>
  </div>
  
   <div class="form-group row">
    <label for="longitude" class="col-sm-2 col-form-label"> Longitude: </label>
    <div class="col-sm-10">
      <input type="longitude" class="form-control" id="longitude" placeholder="Enter your longitude">
    </div>
  </div>
  
     <div class="form-group row">
    <label for="store_active" class="col-sm-2 col-form-label"> Active: </label>
    <div class="col-sm-10">
    <select class="form-select" aria-label="Default select example">
        <option selected>Select Option</option>
        <option value="1">Active</option>
        <option value="2">Inactive</option>
    </select>
  </div>
  
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>


</form>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<script>
    $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
        
         $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4'
        });
</script>
</div>
</body>
</html>