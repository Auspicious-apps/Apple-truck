<?php 

// Data base
require_once("config.php");

$pin_code = $_POST["pin_code"];

$check_sql = "SELECT  pin_code FROM store_pin_code where
 pin_code='$pin_code'";

$result = $conn->query($check_sql);


$row = $result->fetch_assoc();

 $check_size = $row['pin_code'];
 
 
 if(empty($check_size)){
     
    $sql = "INSERT INTO store_pin_code (pin_code)
    VALUES ('$pin_code')";
    
    if (mysqli_query($conn, $sql)) {

        header('location:add_store.php?pin_code_status=pin_code_success');

        exit;
    
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    mysqli_close($conn);

} else {
    
     header('location:add_store.php?pin_code_status_error=pin_code_error');
     exit;
 }
?>