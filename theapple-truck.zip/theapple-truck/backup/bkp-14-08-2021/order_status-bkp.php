<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once("config.php");
require 'mailer/vendor/autoload.php';
$mail = new PHPMailer(true);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://864f811abb112cb228f4ccc5a7df7d35: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@the-apple-truck.myshopify.com/admin/api/2021-07/orders.json',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);
curl_close($curl);
  print_r($response);
 die();
//echo $response;

$orders = json_decode($response,TRUE);
$order = $orders['orders'][0];
    
    $data_html = "<div>";
    $data = [];
    foreach($order['note_attributes'] as $attribute)
    {
        if($attribute['name'] == "location")
        {
            $data['location'] = $attribute['value'];
            $data_html .= "<p> Location ".$attribute['value']."</p>";
        }
        if($attribute['name'] == "address")
        {
            $data['address'] = $attribute['value'];
            $data_html .= "<p> Address ".$attribute['value']."</p>";
        }
        if($attribute['name'] == "picup_date")
        {
            $data['picup_date'] = $attribute['value'];
            $data_html .= "<p> Date ".$attribute['value']."</p>";
        }
    }
    /*$orderLocation = '';
    if($order['note_attributes'][0]['name'] == "location")
    {
        $data['location'] = $order['note_attributes'][0]['value'];
        $orderLocation .= "<p> Location ".$order['note_attributes'][0]['value']."</p>";
    }
    if($order['note_attributes'][0]['name'] == "address")
    {
        $data['address'] = $order['note_attributes'][0]['value'];
        $orderLocation .= "<p> Address ".$order['note_attributes'][0]['value']."</p>";
    }
    if($order['note_attributes'][0]['name'] == "picup_date")
    {
        $data['picup_date'] = $order['note_attributes'][0]['value'];
        $orderLocation .= "<p> Date ".$order['note_attributes'][0]['value']."</p>";
    }
    echo $orderLocation; die("Test");*/
    foreach($order['line_items'] as $item)
    {
        $data['product_name'] = $item['name'];
        $data['price'] = $item['price'];
        $data['quantity'] = $item['quantity'];
        $data_html .= "<p> Item ".$item['quantity']."</p>";
        $data_html .= "<p> Name ".$item['name']."</p>";
        $data_html .= "<p> Price ".$item['price']."</p>";
    }
    $data_html .= "<p> Customer Name ".$order['customer']['first_name']."</p>";
    $data_html .= "<p> Customer Email ".$order['customer']['email']."</p>";
    $data_html .= "<p> Order Number ".$order['order_number']."</p> <div>";

    $data['customer_name'] =  $order['customer']['first_name'];
    $data['customer_email'] = $order['customer']['email'];
    $data['order_number'] = $order['order_number'];
    
    $select = "select * from shopify_order where order_id = ".$order['id'];
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) == 0)
    {
        $barcode = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://tourtheappletruck.com/qrstatus.php';
        $sql = "INSERT INTO shopify_order (order_id,order_number,cust_fname,order_value,order_status,financial_status,barcode) 
        VALUES ('".$order['id']."','".$order['order_number']."','".$order['customer']['first_name']."','".$order['id']."','".$order['order_status_url']."','".$order['financial_status']."','".$barcode."')";
        if (mysqli_query($conn, $sql))
        {
            echo '<div class="alert alert-success">New record has been saved.</div>';
            
            try
            {
                $mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->isSMTP();                  
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true; 
                $mail->Username   = 'info@theapple-truck.com';
                $mail->Password   = 'kimknwyiptcvqtny';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
                $mail->Port       = 587;
                $mail->setFrom('info@theapple-truck.com', 'TheAppleTruck');
                $mail->addAddress($order['email']); 
                $mail->isHTML(true);
                $mail->Subject = 'Order';
                $mail->Body = '<!DOCTYPE html><html><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type"/><title>[SUBJECT]</title><style type="text/css">@media only screen and (max-width:480px){table[class="MainContainer"], td[class="cell"]{width: 100% !important;height:auto !important;}td[class="specbundle"]{width: 100% !important;float:left !important;font-size:14px !important;line-height:18px !important;display:block !important;padding-bottom:15px !important;}td[class="spechide"]{display:none !important;}img[class="banner"]{width: 100% !important; height: auto !important;}}@media only screen and (max-width:540px){table[class="MainContainer"], td[class="cell"]{width: 100% !important;height:auto !important;}td[class="specbundle"]{width: 100% !important;float:left !important;font-size:14px !important;line-height:18px !important;display:block !important;padding-bottom:15px !important;}td[class="spechide"]{display:none !important;}img[class="banner"]{width: 100% !important; height: auto !important;}}</style><script type="colorScheme" class="swatch active">{"name":"Default", "bgBody":"#f1f1f1", "link":"52999E", "color":"999999", "bgItem":"ffffff", "title":"555555"}</script></head><body class="bgBody" leftpadding="0" offset="0" paddingheight="0" paddingwidth="0" style="padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased; padding-top: 0 !important; padding-bottom: 0 !important; padding-top: 0 !important; padding-bottom: 0 !important; margin:0 !important; width: 100% !important; -webkit-text-size-adjust: 100% !important; -ms-text-size-adjust: 100% !important; -webkit-font-smoothing: antialiased !important;" toppadding="0"><table align="center" border="0" cellpadding="0" cellspacing="0" class="tableContent" width="100%"> <tbody> <tr> <td style="padding: 10px;"> <table align="center" border="0" cellspacing="0" style="font-family:helvetica, sans-serif;" width="600" class="MainContainer"> <tbody> <tr> <td style="padding: 10px;"><table width="100%" border="0" cellspacing="0" cellpadding="0"> <tbody><tr> <td valign="top" width="20" style="padding: 10px;">&nbsp;</td><td valign="top" style="padding: 10px;"><table width="100%" border="0" cellspacing="0" cellpadding="0"> <tbody> <tr> <td class="movableContentContainer" style="padding: 10px;"><div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;"></div><div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;"><table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td height="25" style="padding: 10px;"></td></tr><tr><td style="padding: 10px;"><table align="left" border="0" cellpadding="0" cellspacing="0" valign="top" width="100%"><tbody><tr class="header" style=" display: flex; align-items: center; justify-content: space-between; width: 100%;"><td width="269" class="specbundle" style=" margin-top: 30px; display: block; width: 100%; margin-bottom: 50px; padding: 10px; margin-top: 30px; display: block; width: 100%;"><table align="left" border="0" cellpadding="0" cellspacing="0" valign="top" width="100%"><tbody><tr><td width="251" align="left" valign="middle" style="padding: 10px;"><div class="contentEditableContainer contentImageEditable"><div class="contentEditable"><img src="https://cdn.shopify.com/s/files/1/0564/3141/1394/files/The_Apple_Truck_Logo_Black.jpg" style="max-width: 200px; border: 0 !important; display: block !important; outline: none !important;"/></div></div></td></tr></tbody></table></td><td width="269" class="specbundle" style=" margin-top: 30px; display: block; width: 100%; margin-bottom: 50px; padding: 10px; margin-top: 30px; display: block; width: 100%;"><table align="left" border="0" cellpadding="0" cellspacing="0" valign="top" width="100%"><tbody><tr><td width="9" style="padding: 10px;"></td><td width="251" align="left" valign="middle" style="padding: 10px;"><div class="contentEditableContainer contentImageEditable"><div class="contentEditable"> <ul style="margin: 0; padding: 0; list-style: none;"> <li style=" list-style: none; text-align: right; list-style-type: none; font-size: 13px; color: rgb(119,119,119); font-size: 18px; line-height: 24px; padding: 4px 0;">ORDER #"'.$order['order_number'].'"</li></ul></div></div></td><td width="9" style="padding: 10px;" ></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div><div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;"><table class="table-total" border="0" cellpadding="0" cellspacing="0" width="100%" style="text-align: left; margin-top: 20px;"> <thead> <tr><th style="padding: 10px; font-weight: normal; font-size: 24px; margin: 0px 0px 10px;">Hey there!</th> </tr></thead> <tbody> <tr><td style="padding: 10px;"><p style="font-size: 16px;line-height: 24px;margin:0; color: rgb(119,119,119); " class="thank_you"> Thank you so much for your order from The Apple Truck Tour! We cannot wait to see you when we come to your town. Below is the QR code for you to show the Apple slinger when you come to pick up your Apples. You can show this on your phone or print it off. Your choice! We’ll make sure and send a couple reminder emails leading up to your stop. See you soon!</p></td></tr><tr> <td class="peach-text" style="padding: 10px; color: rgb(119,119,119); line-height: 24px; font-size: 16px;">The Apple Truck</td></tr></tbody><tfoot> <tr> <th style="padding: 10px; font-weight: normal; font-size: 24px; margin: 0px 0px 10px;"> <h6 style=" font-weight: normal; font-size: 20px; margin-bottom: 20px;"> Your Pickup Location</h6> </th> </tr><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><p style="color:rgb(119,119,119);font-size: 16px;line-height: 24px;margin:0; line-height:24px;font-size:16px;margin:0px"><b style="color:rgb(119,119,119);">Location</b>: Middletown Peddlers Mall<br></p><p style="color:rgb(119,119,119);line-height:24px; font-size: 16px;line-height: 24px;margin:0; font-size:16px;margin:15px 0px 0px"><b style="color:rgb(119,119,119);">Location Address</b>: 12405 Shelbyville Rd, Louisville, KY 40243, USA<br></p><p style="color:rgb(119,119,119);line-height:24px;font-size:16px;margin:15px 0px 0px"><b style="color:rgb(119,119,119);">Location Date/Time</b>: 06/17/2021 | 12:00 PM - 01:30 PM ET<br></p></td></tr></tfoot> </table></div><div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;"><table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td height="10" style="padding: 10px;"></td></tr><tr><td style="padding: 10px;"><table align="center" border="0" cellpadding="0" cellspacing="0" valign="top" width="100%"><tbody><tr><td style="padding: 10px; margin-top: 30px; display: block; width: 100%; margin-top: 30px; display: block; width: 100%; margin-bottom: 50px; " width="269" class="specbundle"><table align="center" border="0" cellpadding="0" cellspacing="0" valign="top" width="100%"><tbody><tr><td><h3 style="font-weight:normal;font-size:20px;margin:0px 0px 25px">Your QR Code:</h3></td></tr><tr><td style="padding: 10px;"><p style="color:rgb(119,119,119);line-height:24px;font-size:16px;margin:0px"><img src='.$barcode.' alt="qr_code" style="max-width:150px admindeveloper@123" class="CToWUd"></p></td><td style="padding: 10px;" ><h4 style=" padding-left: 30px; font-size:18px;font-weight:500;color:rgb(85,85,85);margin:0px 0px 10px"><b>Show this code to pick up your order</b></h4><ul style=" margin:0;"><li style=" list-style-type: square; font-size: 13px; margin-left:15px;margin-bottom:8px; color: rgb(66,64,64);">Verify your pickup location, date, and time.</li><li style=" list-style-type: square; font-size: 13px; margin-left:15px;margin-bottom:8px; color: rgb(66,64,64);">Get in line and show a team member your QR code</li><li style=" list-style-type: square; font-size: 13px; margin-left:15px;margin-bottom:8px; color:rgb(66,64,64);">Print your QR code or just show us this email on your phone</li><li style=" list-style-type: square; font-size: 13px; margin-left:15px;margin-bottom:8px;color: rgb(66,64,64);">Take your order home and enjoy those apples!</li></ul></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table> </div><table style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto"><tbody><tr><td style="padding: 10px;"> <h3 style="font-weight:normal;font-size:20px;margin:0px 0px 25px">Order summary</h3> </td></tr></tbody> </table><table style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><table style="width:558px;border-spacing:0px;border-collapse:collapse"><tbody><tr style="width:558px"><td style="padding: 10px; font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><table style="border-spacing:0px;border-collapse:collapse"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><img src="https://ci6.googleusercontent.com/proxy/lhV950zVnZzb_1YQWEZ2KB9ldW4X-Lsh8qVQRXp-5HFXhAEwIff0-aO7HrnYNaeOGi31bWaRNaeWJPbLQcdEhcVRh8ci4nz52crdiz8xKTcnk7pEyAzPpeHhgLq2JuzPvpIF1xXaO75YkaxiMp_0IFW-popxp_HNmWkLjiycFA=s0-d-e1-ft#https://cdn.shopify.com/s/files/1/0198/6108/products/Boxes_Large_Singlecopy_compact_cropped.jpg?v=1588344011" align="left" width="60" height="60" style="margin-right:15px;border-radius:8px;border:1px solid rgb(229,229,229)" class="CToWUd"></td><td style="padding: 10px; font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;width:402.703px"><span style="font-size:16px;font-weight:600;line-height:1.4;color:rgb(85,85,85)">25 lb. Box of apples × 1</span><br></td><td style=" padding: 10px; font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;white-space:nowrap"><p align="right" style="color:rgb(85,85,85);line-height:24px;font-size:16px;font-weight:600;margin:0px 0px 0px 15px">$45.00</p></td></tr></tbody></table></td></tr></tbody></table><table style="width:558px;border-spacing:0px;border-collapse:collapse;margin-top:15px;border-top:1px solid rgb(229,229,229)"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;width:221.188px"></td><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><table style="width:332.812px;border-spacing:0px;border-collapse:collapse;margin-top:20px"><tbody><tr><td style=" color:#000;font-size: 16px;line-height: 24px;margin:0; font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px"><p style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">Subtotal</p></td><td align="right" style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px"><strong style="font-size:16px;color:rgb(85,85,85)">$45.00</strong></td></tr><tr><td style=" color:#000;font-size: 16px;line-height: 24px;margin:0; font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px; color:#000;font-size: 16px;line-height: 24px;margin:0; padding: 10px;"><p style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">Shipping</p></td><td align="right" style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px"><strong style="font-size:16px;color:rgb(85,85,85)">$0.00</strong></td></tr><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px"><p style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">Taxes</p></td><td align="right" style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:5px 0px"><strong style="font-size:16px;color:rgb(85,85,85)">$0.00</strong></td></tr></tbody></table><table style="width:332.812px;border-spacing:0px;border-collapse:collapse;margin-top:20px;border-top:2px solid rgb(229,229,229)"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:20px 0px 0px"><p style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">Total</p></td><td align="right" style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding:20px 0px 0px"><strong style="font-size:24px;color:rgb(85,85,85)">$45.00 USD</strong></td></tr></tbody></table></td></tr></tbody> </table></td></tr></tbody></table> <table style="border-spacing:0px;border-collapse:collapse"><tbody> <tr><td><center><table style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><h3 style="font-weight:normal;font-size:20px;margin:0px 0px 25px">Customer information</h3></td></tr></tbody></table><table style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif"><table style="width:558px;border-spacing:0px;border-collapse:collapse"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding-bottom:40px;width:556px"><h4 style=" font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">Billing address</h4><p style="color:rgb(119,119,119);line-height:24px;font-size:16px;margin:0px; color:#000;font-size: 16px;line-height: 24px;margin:0;">Dale Apley<br>317 S. Division<br>80<br>Ann Arbor MI 48104<br>United States</p></td></tr></tbody></table><table style="width:558px;border-spacing:0px;border-collapse:collapse"><tbody><tr><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding-bottom:40px;width:277px"><h4 style=" font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">Contact Info</h4><p style="color:#000;font-size: 16px;line-height: 24px;margin:0; color:rgb(119,119,119);line-height:24px;font-size:16px;margin:0px">Email:&nbsp;<a href="mailto:djapley@gmail.com" rel="noreferrer" target="_blank">"'.$order['customer']['email'].'"</a></p><p style="color:#000;font-size: 16px;line-height: 24px;margin:0; color:rgb(119,119,119);line-height:24px;font-size:16px;margin:15px 0px 0px"></td><td style="font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen,Ubuntu,Cantarell,&quot;Fira Sans&quot;,&quot;Droid Sans&quot;,&quot;Helvetica Neue&quot;,sans-serif;padding-bottom:40px;width:277px"><h4 style=" padding-left: 30px; font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">Payment method</h4><p style="color:rgb(119,119,119);line-height:24px;font-size:16px;margin:0px"><img src="https://ci5.googleusercontent.com/proxy/ClnTx-YysJcvCrM3swKct3jeDFnBqDhP9Ew_-EKcQ1c4Xeo87XDwCj0XhJppm4xvkZyA84xoTnaADnI0hQAF2oqjHPoY3rKZ43SA4BCV_hNsW9ps9vWKpR1FCzXTNM4riUCgt_Ryq5X76fD2-XpjwqtjoslFsuA9PAcbHN-w8fYb0RyPdsaInCJOZ-evfnljWhTCB0HNDflAcCu7WR46SATxuvfamCe7VF6W3K3SZ2P9pfEe=s0-d-e1-ft#https://cdn.shopify.com/shopifycloud/shopify/assets/themes_support/notifications/mastercard-c8d6f1c2e7b63ab95f49954c724c675678d205478e3de8d6f3da384fc068589d.png" height="24" style="height:24px;display:inline-block;margin-right:10px;margin-top:5px; admindeveloper@123" class="CToWUd">&nbsp;Payment method —&nbsp;<strong style="color:rgb(85,85,85)">$45.00</strong></p></td></tr></tbody></table></td></tr></tbody></table></center></td></tr></tbody></table> </td></tr></tbody></table> </td><td valign="top" width="20" style="padding: 10px;">&nbsp;</td></tr></tbody> </table> </td></tr></tbody> </table> </td></tr></tbody> </table> </body></html>';
                $mail->send();
                echo 'Message has been sent';
            }
            catch (Exception $e)
            {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
        else
        {
          '<div class="alert alert-danger">'. $sql . "<br>" . mysqli_error($conn).'</div>';
        }
    }

?>
