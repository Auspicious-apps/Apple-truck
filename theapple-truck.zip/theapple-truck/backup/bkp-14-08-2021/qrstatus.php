<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once("config.php");
require 'mailer/vendor/autoload.php';
$mail = new PHPMailer(true);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://864f811abb112cb228f4ccc5a7df7d35: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@the-apple-truck.myshopify.com/admin/api/2021-07/orders.json',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);
curl_close($curl);
 // print_r($response);
 //die();
//echo $response;

$orders = json_decode($response,TRUE);
$order = $orders['orders'][0];
    
    $data_html = "<div style='padding: 50px;'>";
    $data = [];
     $data_html .= "<h3 style='text-align:center;padding-bottom: 30px;font-family: sans-serif;'>Order Details</h3>";
      $data_html .= "<p style='color:#ea0606;margin-bottom: 35px;letter-spacing: 1px;font-size: 14px;font-family: sans-serif;'>YOUR PICKUP LOCATION</p>";
    foreach($order['note_attributes'] as $attribute)
    {
        
        if($attribute['name'] == "address")
        {
            $data['address'] = $attribute['value'];
            $data_html .= "<p style='color:#ea0606;margin-bottom: 0;font-family: sans-serif;font-size: 12px;'>".$attribute['value']."</p>";
        }
        if($attribute['name'] == "picup_date")
        {
            $data['picup_date'] = $attribute['value'];
            $data_html .= "<p style='border-bottom: 1px solid #ea9f9f;padding-bottom: 50px;margin-bottom: 50px;font-family: sans-serif;font-size: 12px;'> ".$attribute['value']."</p>";
        }
    }
    
   
   
    foreach($order['line_items'] as $item)
   
    {
        $data['product_name'] = $item['name'];
        $data['price'] = $item['price'];
        $data['quantity'] = $item['quantity'];
         
        $data_html .= "<p style='font-family: sans-serif;font-size: 14px;font-weight: 500;'>".$item['quantity'].' x '.$item['name']. " (".$item['price'].")"."</p>";
       // $data_html .= "<p>".$item['name']."</p>";
        //$data_html .= "<p>".$item['price']."</p>";
    }
     $data_html .= "<p style='color:#ea0606;padding-top: 60px;border-top: 1px solid #ea9f9f;margin-top: 50px;font-size: 14px;letter-spacing: 1px;font-family: sans-serif;'>YOUR NAME</p>";
    $data_html .= "<p style='font-family: sans-serif;font-size: 14px;font-weight: 500;'>".$order['customer']['first_name']."</p>";
    
    $data_html .= "<p style='color:#ea0606;font-size: 14px;letter-spacing: 1px;font-family: sans-serif;'>YOUR EMAIL ADDRESS</p>";
    $data_html .= "<p style='font-family: sans-serif;font-size: 14px;font-weight: 500;'>".$order['customer']['email']."</p>";
    
    $data_html .= "<p style='color:#ea0606;font-size: 14px;letter-spacing: 1px;font-family: sans-serif;'>YOUR ORDER NUMBER</p>";
    $data_html .= "<p style='font-family: sans-serif;font-size: 14px;font-weight: 500;'>".$order['order_number']."</p> <div>";

  
    echo $data_html;
?>
