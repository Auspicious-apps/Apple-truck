<?php
// Get our helper functions
require_once("inc/functions.php");
require_once("config.php");
    

// Set variables for our request
$shop = "the-apple-truck";
$token = "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";
$query = array(
  "Content-type" => "application/json" // Tell Shopify that we're expecting a response in JSON format
);

// Run API call to get products
$products = shopify_call($token, $shop, "/admin/products.json", array(), 'GET');

// Convert product JSON information into an array
$products = json_decode($products['response'], TRUE);
?>

<!DOCTYPE html>
<html>
    <?php  require 'layouts/header.php';  ?>
    <link rel="stylesheet" href="layouts/custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php  require 'layouts/nav_bar.php';  ?>
    <style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }
        
        td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
        }
        
        tr:nth-child(even) {
        background-color: #dddddd;
    }

    </style>
    <body>
<div class="container">
    
     <div class="row">
        <div class="col-sm-10">
            <?php 
            if( $_GET['pin_code_status'] == 'pin_code_success') { ?>
                
                <div class="alert alert-success">Thank You! Your Data has been saved!</div>
            <?php } ?>
            
            <?php 
            if( $_GET['delete_store_data_status'] == 'delete_store_data') { ?>
                
                <div class="alert alert-danger">success! Your Data has been Deleted!</div>
            <?php } ?>
            
        </div>
    </div>
       
    <div class="row">
        <div class="col-sm-10">
            <?php 
                if( $_GET['pin_code_status_error'] == 'pin_code_error') { ?>
                <div class="alert alert-danger">Data is Already Exists!</div>
            <?php } ?>
        </div>
      
    </div>
    
     <div class="row">
        <div class="col-sm-10">
            <?php 
                if( $_GET['save_store_status'] == 'success') { ?>
                <div class="alert alert-success">Thank You! Your Data has been saved!</div>
            <?php } ?>
        </div>
      
    </div>
    
    
    
     <div class="row">
        <div class="col-sm-10">
            
<!-- add pin code to db -->
            
<!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">  <i class="fa fa-plus" aria-hidden="true"></i>Add Zip Code: </button>-->
 
  <!-- Modal -->
  <!--<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
        <!--<div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title"> Add Zip Code: </h4>
          </div>
        
        <form action="save_pin_code_data.php" method="POST">
          <div class="modal-body">
              <!--form data-->
                <!--<div class="row">
            <div class="col-sm-6">
              <span>Enter Zip Code :<input required type="text" class="form-control" placeholder="Enter Zip Code.."id="custom_size" name="pin_code"></span>
            </div>
          </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" id="custom_submit">Submit</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
            </div>
         </form>
        </div>
    </div>
  </div>-->
 
  <!-- End Model -->
        
        <!--end code -->
        
  <!-- check availability-->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#check_pin_code">  <i class="fa fa-plus" aria-hidden="true"></i>Check Availability Zip Code</button>
    
    
     <!-- Modal -->
  <div class="modal fade" id="check_pin_code" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title"> Check Zip Code: </h4>
          </div>
        
            <div class="modal-body">
              
              <table>
              <tr>
                <th>Sr.No.</th>
                <th>Available Zip Code</th>
                <!--th>Action</th>-->
              </tr>
            <?php  
            $sql = "SELECT pin_code,id,created_at,updated_at FROM store_data";
            $avialable_result = $conn->query($sql);
            $i=1;
            while($available_size = $avialable_result->fetch_assoc()) { ?>

              <tr>
                <td><?php echo  $i; ?></td>
                <td><?php echo $available_size["pin_code"]; ?></td>
                <!--<td><a onclick="return confirm('Are you sure you want to delete this item?');" href="delete_pin_code_data.php?pin_code_id=<?php echo $available_size["id"]; ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>-->
              </tr>
            <?php  $i++;} ?>
            </table>
            
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
            </div>

        </div>
    </div>
  </div>

 <!-- end -->

        </div>

    </div>
    
    
    
<form  name="myForm" action="save_store.php" method="POST" onsubmit="return validateForm()">
      
      <!--<div class="form-group row">-->
      <!--  <label for="store_id" class="col-sm-2 col-form-label">Store ID:</label>-->
       <!-- <div class="col-sm-10">-->
      <!--        <input type="text" name="store_id" class="col-sm-2">-->
       <!-- </div>-->
      <!--</div>-->
      
      
      <!--<div class="form-group row">
        <label for="pin_code" class="col-sm-2 col-form-label">Zip Code:</label>
        <div class="col-sm-10">
       <?php   
               // $sql = "SELECT pin_code FROM store_pin_code";
               // $result = $conn->query($sql); 
            ?>
          <select class="form-select pin_code" id="pin_code" name="pin_code" aria-label="Default select example">
            <option value="">Select Option </option>
            <?php//  while($row = $result->fetch_assoc()) { 
                //$pin_code =  $row["pin_code"];
            ?>
            <option value="<?php //echo $pin_code; ?>"><?php// echo $pin_code; ?></option>
             <?php// }  ?> 
    
            
        </select>
        </div>
      </div>-->
  
        <input type="hidden" name="latitude" value="" id="latitude">
         <input type="hidden" name="longitude" value="" id ="longitude">
    
     <div class="form-group row">
    
    <label for="location" class="col-sm-2 col-form-label"> Location: </label>
      <div class="col-sm-10">
        <input type="location" class="form-control" id="location" name="location" placeholder="Enter your location">
      </div>
      </div>
      
    <!--  <label for="store_name" class="col-sm-2 col-form-label">Store Name:</label>-->
    <!--  <div class="col-sm-10">-->
    <!--    <input type="text" class="form-control" id="store_name"name="store_name" placeholder="Enter your store">-->
    <!--  </div>-->
    <!--</div>-->
    
    <!--<div class="form-group row">
      
      <label for="current_Date" class="col-sm-2"> Date: </label>
       <div class="col-sm-10">
         
        <input type="date" class="form-control str-dt" id="date" name="date">
      </div>
      
       <label for="start_time" class="col-sm-2"> Start time: </label>
      <div class="col-sm-4">
     
        <input id="input-a" value="click to start time" data-default="20:48" name="start_time" class="start-time form-control">
          
          <select name="start_time_meridian" id ="start_time_meridian" class="col-sm-4 slct-d form-control">
          <option value="">Select an option</option>
            <option value="am">AM</option>
            <option value="pm">PM</option>
        </select>
      </div>
      
    
     <label for="end_time" class="col-sm-2"> End time: </label>
      <div class="col-sm-4">
       
        <input id="input-b" value="click to end time" data-default="20:48" name="end_time" class="start-time form-control">
          
          <select name="end_time_meridian" id="end_time_meridian" class="col-sm-4 slct-d form-control">
          <option value="">Select an option</option>
            <option value="am">AM</option>
            <option value="pm">PM</option>
        </select>
      </div>
      
      
    </div>-->


     <div class="append_date">
                      <div class="mb-3"><button type="button" class="add_more btn btn-primary">Add more time</button></div>
                      <div class="row">
                        <div class="mb-3 col-md-4">
                            <label for="pickup_date">Pickup Date</label>
                            <input type="date" required class="form-control" name="pickup_date[]" id="pickup_date">
                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="pickup_time">Pickup Start Time</label>
                            <input type="time" required class="form-control" name="pickup_start_time[]" id="pickup_time">

                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="pickup_time">Pickup End Time</label>
                            <input type="time" required class="form-control" name="pickup_end_time[]" id="pickup_time">
                           
                        </div>
                        
                         <div class="mb-3 col-md-4">
                            <label for="cars">Select one option:</label>
                            <select  name="selection[]">
                            <option value="">Select A option</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        
                        <div class="mb-3 col-md-4">
                            <label for="date_text" class="col-sm-2 col-form-label"> Date text: </label>
                            <div class="col-sm-10">
                            <input  id="date_text" type="text" class="form-control"  name ="date_text[]" placeholder="Enter your Date Text">
                            </div>
            
                        </div>
                        
                        
                      </div>
        </div><br/>
    
       <!-- <div class="form-group row">
          <label for="date_text" class="col-sm-2 col-form-label"> Date text: </label>
          <div class="col-sm-10">
            <input  id="date_text" type="text" class="form-control" id="date_text" name ="date_text" placeholder="Enter your Date Text">
          </div>
        </div>-->


      <div class="form-group row">
      <label for="address" class="col-sm-2 col-form-label"> Address: </label>
      <div class="col-sm-10">
        <input  id="autocomplete" type="address" class="form-control" id="address" name ="address" placeholder="Enter your Address" onFocus="geolocate()" >
      </div>
    </div>

      <div class="form-group row">
      <label for="city" class="col-sm-2 col-form-label"> City: </label>
        <div class="col-sm-10">
            <input type="city" class="form-control" id="locality" name ="city" value="">
        </div>
    </div>
    
      <div class="form-group row">
      <label for="state" class="col-sm-2 col-form-label"> State: </label>
        <div class="col-sm-10">
            <input type="state" class="form-control" id="administrative_area_level_1" name ="state" placeholder="Enter your State">
        </div>
        </div>
        
        
        <div class="form-group row">
         <label for="state" class="col-sm-2 col-form-label"> Zip code: </label>
            <div class="col-sm-10">
            <input type="text" class="form-control" id="postal_code" name ="zip">
        </div>
        </div>

        
    <!-- <div class="form-group row">-->
    <!--  <label for="latitude" class="col-sm-2 col-form-label"> Latitude: </label>-->
    <!--  <div class="col-sm-10">-->
    <!--    <input type="latitude" class="form-control" id="latitude" name ="latitude" placeholder="Enter your latitude">-->
    <!--  </div>-->
    <!--</div>-->
  
    <!-- <div class="form-group row">-->
    <!--  <label for="longitude" class="col-sm-2 col-form-label"> Longitude: </label>-->
    <!--  <div class="col-sm-10">-->
    <!--    <input type="longitude" class="form-control" id="longitude" name="longitude" placeholder="Enter your longitude">-->
    <!--  </div>-->
    <!--</div>-->
  
     <div class="form-group row">
      <label for="store_active" class="col-sm-2 col-form-label"> Store Status </label>
      <div class="col-sm-10">
      <select class="form-select form-control" id ="status" aria-label="Default select example" name="status">
          <option value="">Select A Option</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
      </select>
    </div>
    </div>
    <div class="form-group row">
      <div class="col-sm-10">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  
</form>

    <div class="clone" style="display:none">
      <div class="row">
        <div class="col-md-4">
            <label for="pickup_date">Pickup Date</label>
            <input type="date" required class="form-control" name="pickup_date[]" id="pickup_date">

        </div>
        <div class="mb-3 col-md-4">
            <label for="pickup_time">Pickup Start Time</label>
            <input type="time" required class="form-control" name="pickup_start_time[]" id="pickup_time">
           
        </div>
        <div class="mb-3 col-md-4">
            <label for="pickup_time">Pickup End Time</label>
            <input type="time" required class="form-control" name="pickup_end_time[]" id="pickup_time">
            
        </div>
        
        <div class="mb-3 col-md-4">
            <label for="cars">Select one option:</label>
            <select  name="selection[]">
            <option value="">Select A option</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            </select>
       
        </div>
        
        
        <div class="mb-3 col-md-4">
            <label for="date_text" class="col-sm-2 col-form-label"> Date text: </label>
            <div class="col-sm-10">
            <input  id="date_text" type="text" class="form-control" name ="date_text[]" placeholder="Enter your Date Text">
            </div>
        </div>
        
      
        <div class="mb-3 col-md-4">
              <button type="button" class="delete_row"id="delete_row">Delete</button>
        </div>
            
     

        
      </div>
    </div>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript">
      
      $('.add_more').on('click',function(){
            var html = $('.clone').find('.row').clone();
            $('.append_date').append(html);
        });
        
        
    </script>
    
     <!-- delete script row -->
     
     <script>
        $(".append_date").on("click",".row .delete_row", function(event) {    
			$(this).closest('.row').css("display", "none");

			    });
     </script>
        
     <!--end -->


 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD0BEltumBd3qxNjIzVwZ7nAIHEhcKfHug&libraries=places&callback=initAutocomplete" async defer></script>
    <script>
      var placeSearch, autocomplete;
      var componentForm = {
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        var place = autocomplete.getPlace();
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng();
        $('input[name=latitude]').val(latitude);
        $('input[name=longitude]').val(longitude);
        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    

<script>
function validateForm() {
   // let x = document.forms["myForm"]["store_id"].value;
       // let store_name = document.forms["myForm"]["store_name"].value;
    let location = document.forms["myForm"]["location"].value;
    
    var date = document.getElementById("date");
    
    var input_a = document.getElementById("input-a");
    
    var start_time_meridian = document.getElementById("start_time_meridian");

    var input_b = document.getElementById("input-b");
    
    var end_time_meridian = document.getElementById("end_time_meridian");
    
    let address = document.forms["myForm"]["address"].value;
    let city = document.forms["myForm"]["city"].value;
    let state = document.forms["myForm"]["state"].value;
    var pin_code = document.getElementById("postal_code");

     
    //let latitude = document.forms["myForm"]["latitude"].value;
    //let longitude = document.forms["myForm"]["longitude"].value;
      
      var status = document.getElementById("status");
    

      if (location == "") {
        alert("Location must be filled out");
        return false;
      }  else if(date.value == "") {
            //If the "Please Select" option is selected display error.
            alert("Please select  Date!");
            return false;
     } else if(input_a.value == "click to start time") {
            //If the "Please Select" option is selected display error.
            alert("Please select start  Date!");
            return false;
     }  else if(start_time_meridian.value == "") {
            //If the "Please Select" option is selected display error.
            alert("Please select an option!");
            return false;
        }  
     
     else if(input_b.value == "click to end time") {
            //If the "Please Select" option is selected display error.
            alert("Please select end  Date!");
            return false;
     }  else if(end_time_meridian.value == "") {
            //If the "Please Select" option is selected display error.
            alert("Please select an opton!");
            return false;
     }   else if(address == "") {
            //If the "Please Select" option is selected display error.
            alert("Address name must be filled out!");
            return false;
     }   else if(city == "") {
            //If the "Please Select" option is selected display error.
            alert("City name must be filled out!");
            return false;
    }  else if(state == "") {
            //If the "Please Select" option is selected display error.
            alert("state name must be filled out!");
            return false;
     }  
 
      else if(pin_code.value == "") {
            //If the "Please Select" option is selected display error.
            alert("pin code  must be filled out!");
            return false;
     }  
     
    //  else  if (latitude == "") {
    //     alert("Latitude name must  be filled out");
    //     return false;
    //   } else  if (longitude == "") {
    //     alert("Longitude name must be filled out");
    //     return false;
    //   } 
         else if(status.value == "") {
            //If the "Please Select" option is selected display error.
            alert("Please select an option!");
            return false;
        }
      
      else {
            return true;
     }
}
</script>

</div>
      <?php require 'layouts/footer.php';  ?>
    </body>
</html>


