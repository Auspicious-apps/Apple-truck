<?php
    
    ini_set('display_errors', 1);
    header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
    
    include("$_SERVER[DOCUMENT_ROOT]/config.php");



    $sql = "select * from  store_data";
    $result = mysqli_query($conn, $sql);
    
    
    $output =array();
    if (mysqli_num_rows($result) > 0) {
    	while($row = mysqli_fetch_assoc($result)){
	             $output[] = array("lat"=>$row['latitude'],"lon"=>$row['longitude'],"location"=>$row['location']
        );   
    	
    	    
    }
    
     echo json_encode($output);
     
}
?>