<?php 
    // Get our helper functions
    //require_once("inc/functions.php");
    
    ini_set('display_errors', 1);
    header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
    
    include("$_SERVER[DOCUMENT_ROOT]/config.php");

    
    $get_zip_code  =  $_POST['zip_code'];
    
    $sql = "SELECT * FROM store_data where pin_code ='$get_zip_code' OR city='$get_zip_code'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
    // output data of each row
    $output =array();
    while ( $row = mysqli_fetch_assoc($result)) {
                                                            
            $output[] = array("id"=>$row['id'],"location"=>$row['location'],
            "check_status"=>$row['check_status'],
            "date_text"=>$row['date_text'],
            "address"=>$row['address'],
            "pick_up_date"=>$row['store_current_date'],
            "start_time"=>$row['start_time'],
            "end_time"=>$row["end_time"],
            "miles"=>$row['miles'],
            "latitude"=>$row['latitude'],
            "longitude"=>$row['longitude'],
            "status"=>$row['status']
        );   

    }          
      //print_r($output);
            echo json_encode($output);

    } else {
        echo "0 results";
    }
    
    mysqli_close($conn);

?>

