<?php 


    // Get our helper functions
    //require_once("inc/functions.php");
    
    ini_set('display_errors', 1);
    header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
    
    include("$_SERVER[DOCUMENT_ROOT]/config.php");
    
    $current_latitude =  $_POST['current_latitude'];
    $current_longitude = $_POST['current_longitude'];
    
    
    $sql =  "UPDATE current_location_table SET current_latitude='$current_latitude',current_longitude='$current_longitude' WHERE id=1";

    $output = mysqli_query($conn, $sql);
    mysqli_close($conn);
    echo json_encode($output);

?>